export const APIKey = <YOURKEYHERE>;
